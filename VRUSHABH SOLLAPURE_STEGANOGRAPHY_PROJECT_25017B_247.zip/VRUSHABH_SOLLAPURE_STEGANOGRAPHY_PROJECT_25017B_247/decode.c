# include "decode.h"
# include "common.h"
#include "decode_types.h"

D_Status read_and_validate_decode_args(char *argv[], decodeInfo *decInfo) 
{
    if(strstr(argv[2],".bmp")) // checking dest file is .bmp or not
    {
        decInfo->dest_image_fname = argv[2];
    }
    else
    {
        printf("Destination File Sholud contain .bmp extension\n");
        return d_failure;
    }
    if(argv[3] == NULL) // if argv[3] equals to NULL give the name to decoded secret file and save it or save it
    {
       decInfo->data_fname = "Decoded_Data";
    }
    else
        decInfo->data_fname = argv[3];
    return d_success;
}

D_Status open_file(decodeInfo *decInfo) // opening the dest file
{
    // Destination Image file
    decInfo->fptr_dest_image = fopen(decInfo->dest_image_fname, "r");
    // Do Error handling
    if (decInfo->fptr_dest_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->dest_image_fname);

        return d_failure;
    }

    // No failure return e_success
    return d_success;
}

D_Status Decode_magic_string(const char *magic_string, decodeInfo *decInfo) // decoding magic string form dest file 
{
    fseek(decInfo->fptr_dest_image, 54, SEEK_SET);
    char arr[8];
    char str[4];
    int i ;
    for (i = 0; i < strlen(magic_string); i++)
    {
        // Read 8 bytes from stego image
        fread(arr, 8, 1, decInfo->fptr_dest_image);
        Decode_byte_to_lsb(arr,&str[i]);
    }
    str[i] = '\0';
    
    // Compare with expected magic string
    if (!(strcmp(str, magic_string)))  
        return d_success;
    else
        return d_failure;

}

D_Status Decode_secret_file_extn_size(decodeInfo *decInfo) // decoding secret file extension size from dest file and storing it
{
    char arr[32];
    uint size;
    fread(arr, 1, 32,decInfo->fptr_dest_image);
    Decode_size_to_lsb(&size, arr);
   decInfo->File_extn_size = size;
   return d_success;  
}

D_Status Decode_secret_file_extn(decodeInfo *decInfo) // Decoding secret file extension from dest file and adding the extension to decoded secret file
{
   char arr[8];
    char str[decInfo->File_extn_size + 1]; 
    int i;

    for (i = 0; i < decInfo->File_extn_size; i++)
    {
        fread(arr, 8, 1, decInfo->fptr_dest_image);
        Decode_byte_to_lsb(arr, &str[i]);
    }
    str[i] = '\0';  

    printf("Secret File Extension --> %s is Decoded\n", str);

    char temp_fname[100];  
    strcpy(temp_fname, decInfo->data_fname);

    char *base = strtok(temp_fname, "."); // removing if file containg extension
    if (base == NULL)
        base = temp_fname; 

    char new_filename[150];
    strcpy(new_filename, base);  // copying extension 
    strcat(new_filename, str);   // combining the secret file extension with decoded secret file name 
    printf("Decoded Output Filename: %s\n", new_filename);

    // open new file
    decInfo->fptr_data = fopen(new_filename, "w"); // opening the secret file 
    if (decInfo->fptr_data == NULL)
    {
        puts("File Not Exist\n");
        return 0;
    }

    return d_success;
}

D_Status Decode_secret_file_size(decodeInfo *decInfo) // decoding the secert file size from dest file and storing it
{
    char arr[32];
    uint size;
    fread(arr, 1, 32,decInfo->fptr_dest_image);
    Decode_size_to_lsb(&size, arr);
    decInfo->Secret_File_extn_size = size; // To store the secret data size
    return d_success;
}

D_Status Decode_secret_file_data(decodeInfo *decInfo) // decoding secret file data from dest file and copying it
{
    char arr[8];
    char str[decInfo->Secret_File_extn_size];
    int i ;
    for (i = 0; i < decInfo->Secret_File_extn_size; i++)
    {
        // Read 8 bytes from stego image
        fread(arr, 8, 1, decInfo->fptr_dest_image);
        Decode_byte_to_lsb(arr,&str[i]);
    }
    str[i] = '\0';
    fwrite(str,1,decInfo->Secret_File_extn_size,decInfo->fptr_data); // copying the secret data to decoded secret file 
}

D_Status Decode_byte_to_lsb(char* arr,char* str) // decoding byte to lsb
{ 
    unsigned char data = 0;

    for (int i = 0; i < 8; i++)
    {
        char bit = arr[i] & 1; // geting the lsb bit
        data |= (bit << (7 - i)); // moving i times and store the bit
    }
    *str = data;
    return d_success;
}

D_Status Decode_size_to_lsb(int* size, char *imageBuffer) // decoding size to lsb
{
    unsigned char data = 0;
    for (int i = 31; i >= 0; i--)
    {
        char bit =imageBuffer[i] & 1; // to get lsb bit 
        data |= (bit << i);
    }
    *size = data;
    return d_success;
}

D_Status do_decoding(decodeInfo *decInfo) // function calling from Do_Decoding    
{
    if ((open_file(decInfo))== d_success)
    {
    printf("Destination File opened \n");
    if(Decode_magic_string(MAGIC_STRING,decInfo))
    {
    printf("Magic String --> %s is Decoded \n",MAGIC_STRING);
    if (Decode_secret_file_extn_size(decInfo))
    {
    printf("Size Of The File Extension --> %d is Decoded\n",decInfo->File_extn_size);
    if (Decode_secret_file_extn(decInfo))
    {
    printf("Decode Secret File Name is --> %s\n",decInfo->data_fname);
    printf("Secret File --> %s is File Opened\n",decInfo->data_fname);
    if (Decode_secret_file_size(decInfo))
    {
    printf("Secret Data Length --> %d is Decoded\n",decInfo->Secret_File_extn_size);
    if ( Decode_secret_file_data(decInfo))
    {
    printf("Secret Information Is Decoded in File --> %s\n",decInfo->data_fname);
    printf("Decoded Successfully...\n");
    }
    else
    printf("Secret Information Is Not Decoded in --> %s File\n",decInfo->data_fname);
    }
    else
    printf("Secret Data is  Length is Not Decoded\n");
                    
                    
    }
    else
    printf("Secret File Extension Not Decoded\n");
                
    }
    else
    printf("Size Of The File Extension Not Decoded\n");
    }
        else
        printf("Magic String Is Not Decoded Properlly\n");
    }
    else
        printf("Destination File is Not Open\n");
    
}