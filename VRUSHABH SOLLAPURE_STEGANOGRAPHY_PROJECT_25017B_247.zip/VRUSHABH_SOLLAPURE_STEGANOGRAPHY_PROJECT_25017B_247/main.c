/*
Name : VRUSHABH SOLLAPURE
Date : 13/10/2025
DES : LSB Bit Steganography
......... For Encoding The Data............
Sample Input : ./a.out -e beautiful.bmp secret.txt
Sample Output : Encoding....
                Files Opened
                width = 1024
                height = 768
                Secret File Size is less Then Image_Capacity of beautiful.bmp File
                Header is Encoded from from beautiful.bmp to default.bmp File
                Magic String is Encoded
                Secret File Extension is Encoded
                Secret File Extension Size is Encoded
                Secret File  Size is Encoded
                Secret File Data is Encoded
                Remaining Image data is copied from beautiful.bmp to default.bmp File
                Encoding Sucessfull

......... For Decoding The Data ........
Sample Input : ./a.out -d default.bmp
Sample Output : Decoding...
                Destination File opened 
                Magic String --> #* is Decoded
                Size Of The File Extension --> 4 is Decoded
                Secret File Extension --> .txt is Decoded
                Decoded Output Filename: Decoded_Data.txt
                Decode Secret File Name is --> Decoded_Data
                Secret File --> Decoded_Data is File Opened
                Secret Data Length --> 37 is Decoded
                Secret Information Is Decoded in File --> Decoded_Data.txt
                Decoded Successfully...

*/
#include <stdio.h>
#include "encode.h"
#include "types.h"
#include "decode_types.h" // Contains user defined types
#include "decode.h"
OperationType check_operation_type(char *);

int main(int argc, char *argv[])
{
    
    // Step 1 : Check the argc >= 4 true - > step 2
    if(argc >= 3)
    {
        OperationType ret = check_operation_type(argv[1]);
        if((argc ==  4 || argc ==  5) && ret == e_encode)
        {
            // Call the check_operation_type(argv[1]) == e_encode )) true - > 
            
            EncodeInfo encInfo; // declare the structure variable for encode
            printf("Encoding....\n");
            if(read_and_validate_encode_args(argv,&encInfo) == d_success) //  Call the read_and_validate_encode_args(argv,&enc_info)== e_success)
            {
                do_encoding(&encInfo);  // Call the do_encoding (&encInfo);
            }
            
        }
        else if( ret == e_decode && (argc ==  4 || argc ==  3))
        {
            decodeInfo decInfo; // declare structure variable for decoding
            printf("Decoding...\n");
            if(read_and_validate_decode_args(argv,&decInfo) == d_success)
            {
                do_decoding(&decInfo);
            }
        
        }
        else 
        {
            printf("In correct argument -> '%s' { Use only '-d' (Decode) / '-e' (Encode)}\n",argv[1]);
            return 0;
        }
    }
    else  //  false - > terminate the program
    {
        printf("Error : CLA Should Contain :- |4 or 5 Arguments For Encoding |\n\t\t\t      |3 or 4 Arguments For Decoding |\n");
        return 0;
    }
    
    return 0;
}

OperationType check_operation_type(char *symbol)
{
    // Step 1 : Check whether the symbol is -e or not true - > return e_encode false -> Step 2
    if((strcmp(symbol,"-e") == 0))
    {
        return e_encode;
    }
    // Step 2 : Check whether the symbol is -d or not true - > return e_decode false -> return e_unsupported
    else if((strcmp(symbol,"-d") == 0))
    {
        return e_decode;
    }
    else{
        return e_unsupported;
    }
}
