#include <stdio.h>
#include "encode.h"
#include "types.h"
#include "common.h"
/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

uint get_file_size(FILE *fptr)
{
    // Find the size of secret file data
    fseek(fptr, 0, SEEK_END);
    uint size = ftell(fptr);
    return size;
}

/*
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */

Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    if((strstr(argv[2],".bmp"))) // Checking SRC FILE is .bmp or not
    {
        encInfo->src_image_fname = argv[2];
       
    }
    else
    {
        printf("The Source File Extension Should Be : '.bmp'\n ");
        return e_failure;
    }
    if((strstr(argv[3],".txt") || strstr(argv[3],".c") || strstr(argv[3],".sh"))) // Checking SECRET FILE is extension or not
    {
        encInfo->secret_fname = argv[3];
    }
    else
    {
        printf("The Secret File Extension Should Be : ( '.txt' / '.sh' / '.c' )\n ");
        return e_failure;
    }
    if(argv[4] == NULL) // Checking the Argv[4] is NULL and crete the Default File
    {
        encInfo->stego_image_fname = "default.bmp";
    }
    else
    {
        if ((strstr(argv[4],".bmp"))) // IF argv[4] not equal to NULL, Check for .bmp or not 
        {
            encInfo->stego_image_fname = argv[4];
        }
        else
        {
            printf("The Destination File Extension Should Be : '.bmp'\n ");
            return e_failure;
        }
    }
    return e_success;
}

Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

        return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

        return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

        return e_failure;
    }

    // No failure return e_success
    return e_success;
}

Status check_capacity(EncodeInfo *encInfo)
{
    encInfo ->image_capacity=get_image_size_for_bmp(encInfo->fptr_src_image); // To Store SRC Image Size
    encInfo ->size_secret_file=get_file_size(encInfo->fptr_secret); // TO Store SECRET FILE Size
    char *extn=strstr(encInfo->secret_fname,"."); // TO copy address of secret file extension

    strcpy(encInfo ->extn_secret_file,extn); // To Store the extension of secret file

    uint size=(54+(strlen(MAGIC_STRING)+4+(strlen(encInfo ->extn_secret_file))+4+ encInfo ->size_secret_file)*8); // Total size to encode the data
  
    if(encInfo->image_capacity>size) // Checking for the image size is greather then total size  
        return e_success;
    else
        return e_failure;
}

Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_stego_image) // Copying header from src to dest file
{
    char header[54];
    rewind(fptr_src_image); // before copying the header offset to zero
    fread(header,54,1,fptr_src_image);
    fwrite(header,54,1,fptr_stego_image);
    if(ftell(fptr_src_image) == ftell(fptr_stego_image)) // Checking the offset of src file and dest file is equal or not
        return e_success;
    else
        return e_failure;

}
Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo) // Encoding the Magic String and copying to dest file
{
    char arr[8];
    for(int i=0;i<strlen(magic_string);i++)
    {
        fread(arr, 8, 1, encInfo->fptr_src_image);
        encode_byte_to_lsb(magic_string[i], arr);
        fwrite(arr, 8, 1, encInfo->fptr_stego_image);
    }
    if(ftell(encInfo->fptr_src_image)==ftell(encInfo->fptr_stego_image)) // Checking the offset of src file and dest file is equal or not
        return e_success;
    else
        return e_failure;
}
Status encode_secret_file_extn_size(int size, EncodeInfo *encInfo) // Encoding the secret file extension size and copying to dest file
{
    char arr[32];
    fread(arr,32,1,encInfo->fptr_src_image);
    encode_size_to_lsb(size,arr);
    fwrite(arr,32,1,encInfo->fptr_stego_image);
    if(ftell(encInfo->fptr_src_image)==ftell(encInfo->fptr_stego_image)) // Checking the offset of src file and dest file is equal or not
        return e_success;
    else
        return e_failure;
}

Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo) // Encoding the Secret File extension and copying to dest file
{
    char arr[8];
    for(int i=0;i<strlen(file_extn);i++)
    {
        fread(arr, 8, 1, encInfo->fptr_src_image);
        encode_byte_to_lsb(file_extn[i], arr);
        fwrite(arr, 1, 8, encInfo->fptr_stego_image);
    }
    if(ftell(encInfo->fptr_src_image)==ftell(encInfo->fptr_stego_image))  // Checking the offset of src file and dest file is equal or not
        return e_success;
    else
        return e_failure;
}

Status encode_secret_file_size(long file_size, EncodeInfo *encInfo) // Encoding the secret file size and copying to dest file
{
    char arr[32];
    fread(arr,32,1,encInfo->fptr_src_image);
    encode_size_to_lsb(file_size,arr);
    fwrite(arr,32,1,encInfo->fptr_stego_image);
    if(ftell(encInfo->fptr_src_image)==ftell(encInfo->fptr_stego_image))  // Checking the offset of src file and dest file is equal or not
        return e_success;
    else
        return e_failure;
}

Status encode_secret_file_data(EncodeInfo *encInfo)  // Encoding the Secret File data and copying to dest file
{ 
    rewind(encInfo->fptr_secret);
    fread(encInfo->secret_data,encInfo->size_secret_file,1, encInfo->fptr_secret);
    char arr[8];
    for(int i=0;i<encInfo->size_secret_file;i++)
    {
        fread(arr, 8, 1, encInfo->fptr_src_image);
        encode_byte_to_lsb(encInfo->secret_data[i], arr);
        fwrite(arr, 1, 8, encInfo->fptr_stego_image);
    }
    if(ftell(encInfo->fptr_src_image)==ftell(encInfo->fptr_stego_image))  // Checking the offset of src file and dest file is equal or not
        return e_success;
    else
        return e_failure;
}

Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest) //Copying the remaining data from src to dest file
{
    char buffer;
    while(fread(&buffer,1,1,fptr_src) > 0){
        fwrite(&buffer,1,1,fptr_dest);
    }
    if(ftell(fptr_src)==ftell(fptr_dest))   // Checking the offset of src file and dest file is equal or not
        return e_success;
    else
        return e_failure;
}

Status encode_byte_to_lsb(char data, char *image_buffer) // encoding byte to lsb of data
{
    for(int i=7;i>=0;i--)
    {
        image_buffer[7-i]=image_buffer[7-i]&~1; //clear the lsb bit
        image_buffer[7-i]=data>>i &1 | image_buffer[7-i];
    }
    return e_success;
}

Status encode_size_to_lsb(int size, char *imageBuffer) // encoding size to lsb 
{
    for(int i=31;i>=0;i--)
    {
        imageBuffer[i]=imageBuffer[i]&~1;  //clear the lsb bit
        imageBuffer[i]= size>>i &1 | imageBuffer[i];
    }
        return e_success;
}

Status do_encoding(EncodeInfo *encInfo)
{
    if(open_files(encInfo)) // open files function call
    {
        printf("Files Opened\n");
        if(check_capacity(encInfo)) // check capacity function call
        {
            printf("Secret File Size is less Then Image_Capacity of %s File\n",encInfo->src_image_fname);
            if(copy_bmp_header(encInfo->fptr_src_image,encInfo->fptr_stego_image)) // copy header function call
            {
                printf("Header is Encoded from from %s to %s File\n",encInfo->src_image_fname,encInfo->stego_image_fname);
                if(encode_magic_string(MAGIC_STRING, encInfo))
                {
                    printf("Magic String is Encoded\n");
                    if(encode_secret_file_extn_size(strlen(encInfo->extn_secret_file), encInfo))
                    {
                        printf("Secret File Extension is Encoded\n");
                        if(encode_secret_file_extn(encInfo->extn_secret_file, encInfo))
                        {
                            printf("Secret File Extension Size is Encoded\n");
                            if(encode_secret_file_size(encInfo->size_secret_file, encInfo))
                            {
                                printf("Secret File  Size is Encoded\n");
                                if(encode_secret_file_data(encInfo))
                                {
                                    printf("Secret File Data is Encoded\n");
                                    if(copy_remaining_img_data(encInfo->fptr_src_image,encInfo->fptr_stego_image))
                                    {
                                        printf("Remaining Image data is copied from %s to %s File\n",encInfo->src_image_fname,encInfo->stego_image_fname);
                                        printf("Encoding Sucessfull\n");
                                    }
                                    else
                                        printf("Remaining Image data from %s to %s  File is not copied\n",encInfo->src_image_fname,encInfo->stego_image_fname);
                                }
                                else
                                    printf("Secret File Data is not Encoded\n");
                            }
                            else
                                printf("Secret File  Size is Not Encoded\n");

                        }
                        else
                            printf("Secret File Extension Size is Not Encoded\n");
                    }
                    else
                        printf("Secret File Extension is Not Encoded\n");
                }
                else
                    printf("Magic String is Not Encoded\n");
                
            }
            else
            {
                printf("Header is not Encoded from source to destination file\n");
            }
        }
        else
        {
            printf("Secret File Size is More Then Image_Capacity\n");
        }
    }
}