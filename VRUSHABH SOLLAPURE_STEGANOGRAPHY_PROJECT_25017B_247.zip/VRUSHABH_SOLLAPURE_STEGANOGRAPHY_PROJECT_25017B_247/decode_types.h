#ifndef DECODE_TYPES_H
#define DECODE_TYPES_H

/* User defined types */
typedef unsigned int uint;

/* Status will be used in fn. return type */
typedef enum
{
    d_failure,
    d_success
} D_Status;


#endif