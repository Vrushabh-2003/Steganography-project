#ifndef DECODE_H
#define DECODE_H
#include <stdio.h>
#include <string.h>
#include "common.h"
#include "decode_types.h" // Contains user defined types


typedef struct _decodeInfo
{
    /* Source Image info */
    char *dest_image_fname; // To store the dest image name
    FILE *fptr_dest_image;  // To store the address of the dest image
    uint File_extn_size; // To store the file extension size of after decoding
    uint Secret_File_extn_size ; // To store the secret file extension size of after decoding
    char* data_fname;// To store the Received Secret Data Name
    FILE* fptr_data; // To store the address of the Received Secret Data

} decodeInfo;

D_Status read_and_validate_decode_args(char *argv[], decodeInfo *decInfo);

D_Status do_decoding(decodeInfo *decInfo);

/* Get File pointers for i/p and o/p files */
D_Status open_file(decodeInfo *decInfo);

/* Decode Magic String */
D_Status Decode_magic_string(const char *magic_string, decodeInfo *decInfo);

/*Decode extension size*/
D_Status Decode_secret_file_extn_size(decodeInfo *decInfo);

/* Decode secret file extenstion */
D_Status Decode_secret_file_extn(decodeInfo *decInfo);

/* Decode secret file size */
D_Status Decode_secret_file_size(decodeInfo *decInfo);

/* Decode secret file data*/
D_Status Decode_secret_file_data(decodeInfo *decInfo);

/* Decode a byte into LSB of image data array */
D_Status Decode_byte_to_lsb(char* arr,char* str);

// Decode a size to lsb
D_Status Decode_size_to_lsb(int* size, char *imageBuffer);

#endif